<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>

  </head>
  <body>
<footer>
<div class="footer">
    <p>Date: <?php echo date('Y-m-d'); ?></p>
    <p>Dairy Direct</p>
</div>

</footer>
  </body>
</html>
